package com.example.sporton

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class ImcActivity : AppCompatActivity() {


    private lateinit var btnCalcular: Button
    private lateinit var editPeso: EditText
    private lateinit var editAltura: EditText
    private lateinit var btnHome: Button
    private lateinit var btnAgenda: Button

    @SuppressLint("MissingInflatedId", "SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_imc)

        btnHome = findViewById(R.id.btnHome)
        btnAgenda = findViewById(R.id.btnAgenda)

        btnCalcular = findViewById(R.id.btn_calcular)
        editPeso = findViewById(R.id.edit_peso)
        editAltura = findViewById(R.id.edit_altura)

        btnCalcular.setOnClickListener {


            val intentg = Intent(this, ResultadoActivity::class.java)
            val peso = editPeso.text.toString()
            val altura = editAltura.text.toString()

            if (peso.isNotEmpty() && altura.isNotEmpty()) {

                intentg.putExtra("peso", peso.toDouble())
                intentg.putExtra("altura", altura.toDouble())

                startActivity(intentg)

            }
        }

        btnHome.setOnClickListener {

            val intente = Intent(this, MainActivity::class.java)
            startActivity(intente)

        }

        btnAgenda.setOnClickListener {
            val intentf = Intent(this, AgendaActivity::class.java)
            startActivity(intentf)
        }

    }
}