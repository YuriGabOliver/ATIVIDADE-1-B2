package com.example.sporton
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class AgendaActivity : AppCompatActivity() {

    private lateinit var btnImc: Button
    private lateinit var btnHome: Button

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_agenda)


        btnImc = findViewById(R.id.btnImc)
        btnHome = findViewById(R.id.btnHome)


        btnImc.setOnClickListener {
            val intentc = Intent(this, ImcActivity::class.java)
            startActivity(intentc)
        }


        btnHome.setOnClickListener {
            val intentd = Intent(this, MainActivity::class.java)
            startActivity(intentd)
        }

    }

}
