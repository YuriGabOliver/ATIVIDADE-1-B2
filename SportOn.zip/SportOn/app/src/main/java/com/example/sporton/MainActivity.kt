package com.example.sporton

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity() {

    private lateinit var btnImc: Button
    private lateinit var btnAgenda: Button
    private lateinit var btnPerfil: Button
    private lateinit var imagemPerfil: ImageView
    private val REQUEST_IMAGE_CAPTURE = 1

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        btnImc = findViewById(R.id.btnImc)
        btnAgenda = findViewById(R.id.btnAgenda)
        btnPerfil = findViewById(R.id.btnPerfil)
        imagemPerfil = findViewById(R.id.imagePerfil)


        btnImc.setOnClickListener {
            val intenta = Intent(this, ImcActivity::class.java)
            startActivity(intenta)
        }


        btnAgenda.setOnClickListener {
            val intentb = Intent(this, AgendaActivity::class.java)
            startActivity(intentb)


        }
        btnPerfil.setOnClickListener {
            val intenth = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            startActivityForResult(intenth, REQUEST_IMAGE_CAPTURE)


        }
    }

    @Deprecated("This method has been deprecated in favor of using the Activity Result API\n      which brings increased type safety via an {@link ActivityResultContract} and the prebuilt\n      contracts for common intents available in\n      {@link androidx.activity.result.contract.ActivityResultContracts}, provides hooks for\n      testing, and allow receiving results in separate, testable classes independent from your\n      activity. Use\n      {@link #registerForActivityResult(ActivityResultContract, ActivityResultCallback)}\n      with the appropriate {@link ActivityResultContract} and handling the result in the\n      {@link ActivityResultCallback#onActivityResult(Object) callback}.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK){
            val imageBitmap = data?.extras?.get("data") as Bitmap
            imagemPerfil.setImageBitmap(imageBitmap)

        }
    }
}